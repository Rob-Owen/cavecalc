# CaveCalc
## Cave Geochemical Modelling Software

This repository contains the source code for CaveCalc. CaveCalc is software for geochemical modelling of speleothem and dripwater chemistry and isotopes. 

Users may clone the directory and follow the installation instructions given in manual.pdf. In addition, source distributions (.zip & .tar.gz) are provided in the dist sub-directory. See manual.pdf for installation and basic useage instructions.