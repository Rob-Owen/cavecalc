from cavecalc.gui.gui import CCAnalyseGUI
import tkinter as tk

if __name__ == '__main__':
    root = tk.Tk()
    app = CCAnalyseGUI(root)
    root.mainloop()