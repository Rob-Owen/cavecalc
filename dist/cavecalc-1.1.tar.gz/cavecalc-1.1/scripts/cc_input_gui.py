from cavecalc.gui.gui import CCInputGUI
import tkinter as tk

if __name__ == '__main__':
    root = tk.Tk()
    app = CCInputGUI(root)
    root.mainloop()